// for addon compatibility issue only
